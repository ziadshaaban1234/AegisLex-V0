# AegisLex — Phase 4: Translation Coverage Report

## Statistics

| Metric | Count |
|---|---|
| New Phase 4 translation keys added (EN + AR) | 142 |
| lang.t() calls in cases-list HTML | 30 |
| lang.t() calls in cases-list TS | 12 |
| lang.t() calls in case-detail HTML | 42 |
| lang.t() calls in case-detail TS | 10 |
| lang.t() calls in case-form HTML | 28 |
| lang.t() calls in case-form TS | 8 |
| lang.t() calls in upload HTML | 32 |
| lang.t() calls in upload TS | 4 |
| lang.t() calls in timeline HTML | 10 |
| lang.t() calls in timeline TS | 3 |
| lang.t() calls in contract-viewer HTML | 36 |
| lang.t() calls in contract-viewer TS | 6 |
| **Total Phase 4 lang.t() calls** | **221** |

## Key Groups Added

| Group | Keys |
|---|---|
| Cases List chrome | 10 |
| Cases filter option labels | 3 |
| Case status labels | 6 |
| Case priority labels | 4 |
| Case type labels | 6 |
| Cases table headers | 7 |
| Cases empty states | 3 |
| Cases grid card | 1 |
| Cases action labels | 3 |
| Delete confirm dialog | 4 |
| Pagination | 3 |
| Toast messages (cases) | 4 |
| Case Detail page chrome | 10 |
| Risk banner descriptions | 3 |
| Case Detail tabs | 5 |
| Case Overview fields | 8 |
| Quick Actions card | 9 |
| Documents tab | 5 |
| Analysis tab | 4 |
| Timeline/Graph tab redirects | 6 |
| Case Form labels/placeholders | 14 |
| Case Form tips | 9 |
| Upload page | 28 |
| Timeline page | 11 |
| Document Viewer | 27 |
| **Total** | **142** |

## Coverage by Section

| Section | Covered | Kept (data/mock) | Notes |
|---|---|---|---|
| Cases list header | ✓ | | |
| Cases search + filters | ✓ | | |
| Cases table headers | ✓ | | |
| Priority labels | ✓ | | |
| Status labels | ✓ | | |
| Cases empty states | ✓ | | |
| Delete dialog | ✓ | | |
| Pagination | ✓ | | |
| Case titles/numbers | — | ✓ | User data |
| Case detail header | ✓ | | |
| Risk banner | ✓ | | |
| All 5 tabs | ✓ | | |
| Overview field labels | ✓ | | |
| Case description text | — | ✓ | User content |
| Quick Actions | ✓ | | |
| Documents tab chrome | ✓ | | |
| File names | — | ✓ | User data |
| Analysis tab chrome | ✓ | | |
| AI analysis content | — | ✓ | AI results |
| Timeline/Graph redirects | ✓ | | |
| Case form labels | ✓ | | |
| Form validation errors | ✓ | | |
| Getting Started tips | ✓ | | |
| Upload drop zone | ✓ | | |
| Upload queue | ✓ | | |
| All Done banner | ✓ | | |
| Format info cards | ✓ | | |
| Timeline filters | ✓ | | |
| Timeline events (content) | — | ✓ | AI/data content |
| Viewer toolbar | ✓ | | |
| Viewer controls | ✓ | | |
| Viewer panel tabs | ✓ | | |
| Extracted text content | — | ✓ | Document content |
| AI analysis text | — | ✓ | AI results |
| Risk item titles/desc | — | ✓ | AI results |
| Entity values | — | ✓ | AI results |
