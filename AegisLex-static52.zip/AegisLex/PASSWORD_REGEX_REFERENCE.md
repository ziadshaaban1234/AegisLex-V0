# Password Regex Reference

For backend developers. Source of truth:
`src/app/shared/auth-components/auth-validators.ts` (unmodified by this
change — copied here for reference only).

All password values are `trim()`-med before any length check or regex test.

---

## PASSWORD_UPPERCASE_REGEX

```
/[A-Z]/
```

**Purpose:** Confirms the password contains at least one uppercase letter
(A–Z).

**Accepted (matches found):** `Password1!`, `aB3#defg`, `STRONGpass9$`

**Rejected (no match):** `password1!`, `lowercase9$`, `12345678!`

**Explanation:** A single unanchored character-class test. It does not check
position or count — only that at least one of `A` through `Z` exists
somewhere in the string.

---

## PASSWORD_LOWERCASE_REGEX

```
/[a-z]/
```

**Purpose:** Confirms the password contains at least one lowercase letter
(a–z).

**Accepted:** `Password1!`, `aB3#defg`

**Rejected:** `PASSWORD1!`, `12345678!`

**Explanation:** Mirror of the uppercase check, lowercase range only.

---

## PASSWORD_NUMBER_REGEX

```
/\d/
```

**Purpose:** Confirms the password contains at least one digit (0–9).

**Accepted:** `Password1!`, `aB3#defg`

**Rejected:** `Password!`, `NoDigitsHere!`

**Explanation:** `\d` is equivalent to `[0-9]`. Unanchored — a single digit
anywhere in the string satisfies it.

---

## PASSWORD_SPECIAL_REGEX

```
/[^\w\s]/
```

**Purpose:** Confirms the password contains at least one special
(non-alphanumeric, non-underscore, non-whitespace) character.

**Accepted:** `Password1!`, `aB3#defg`, `Pass-word1`

**Rejected:** `Password1`, `Password_1` (underscore is a word character, so
it does NOT count as special), `Pass word1` (a space is whitespace, also
does NOT count)

**Explanation:** `\w` matches `[A-Za-z0-9_]`; `\s` matches whitespace. The
negated class `[^\w\s]` therefore matches anything that is neither a letter,
digit, underscore, nor whitespace — e.g. `! @ # $ % ^ & * ( ) - + = [ ] { }
| ; ' " , . < > / ?`.

---

## Composite rule — `passwordValidator`

Applied to: Register's New Password, Reset Password's New Password, and (as
of this change) Profile's **Current Password** and **New Password**.

Length and composition checks (all must pass; trimmed value):

| Check        | Condition                              | Error key     |
|--------------|------------------------------------------|---------------|
| Required     | non-empty after trim                     | `required`    |
| Min length   | `length >= 8`                            | `pwTooShort`  |
| Max length   | `length <= 64`                           | `pwTooLong`   |
| Uppercase    | `PASSWORD_UPPERCASE_REGEX` matches       | `pwNoUpper`   |
| Lowercase    | `PASSWORD_LOWERCASE_REGEX` matches       | `pwNoLower`   |
| Number       | `PASSWORD_NUMBER_REGEX` matches          | `pwNoNumber`  |
| Special char | `PASSWORD_SPECIAL_REGEX` matches         | `pwNoSpecial` |

**Accepted examples:** `Aegis123!`, `LawFirm$2025`, `Cl@udeReview9`

**Rejected examples:** `abc` (too short, no upper/number/special), `1234`
(too short, no letters/special), `alllowercase1!` (no uppercase),
`ALLUPPERCASE1!` (no lowercase), `NoNumbersHere!` (no number),
`NoSpecialChar9` (no special character)

This is the rule that now governs **Profile → Current Password**'s
neutral/invalid/valid state: a short or incomplete value (e.g. `abc`) will
never render as valid, regardless of the `required` check passing.

---

## Backend implementation notes

These are frontend-only format checks and provide no security guarantee on
their own. The backend must:
1. Independently enforce equivalent (or stricter) password composition rules
   server-side — never trust client-side validation alone.
2. Verify Current Password against the stored credential hash and return
   `{ success: false, message: "Current password is incorrect" }` on
   mismatch, per the contract documented in `PROFILE_PASSWORD_SECURITY_FLOW.md`.
3. Never include the old or new plaintext password in logs or error
   responses beyond the documented `message` field.
