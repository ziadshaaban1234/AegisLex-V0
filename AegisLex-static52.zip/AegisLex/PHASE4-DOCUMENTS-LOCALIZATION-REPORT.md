# AegisLex — Phase 4: Documents Localization Report

## Files Modified

| File | Change |
|---|---|
| `contract-viewer.component.ts` | Injected LanguageService; `panels` computed with `lang.t()`; `getRiskDesc`, `download` toast, `analyze` toast, `formatDate` localized |
| `contract-viewer.component.html` | 36 `lang.t()` bindings replacing all hardcoded UI text in toolbar, controls, panels, risk banner, empty states |

## What Was Localized

### Document Viewer (contract-viewer)

**Toolbar**
- Back link label ("Cases")
- Document language label ("Language:")
- Analyze / Analyzing... button
- Download aria-label
- "Full Analysis" link label

**Zoom Controls**
- Zoom out aria-label
- Reset zoom aria-label (100%)
- Zoom in aria-label

**Pagination Controls**
- Previous page aria-label
- Next page aria-label
- Page `aria-label` on container: "Page {n} of {n}"

**Risk Banner**
- "Risk Score:" label
- Risk description: "High risk — review required" / "Medium risk — some concerns" / "Low risk — looks good"

**Side Panel Tabs (all 4)**
- Extracted Text
- AI Analysis
- Risks
- Entities

**Analysis Panel**
- "Risks" section title
- "Entities" section title
- Analyzing state: "Saul is analyzing..."
- No-analysis empty state: "Run Analysis"
- Run Analysis button label

**Risks Panel**
- No-risks empty state: "No risks detected"
- Run Analysis prompt
- Risk severity labels use `titlecase` pipe (not translated — these are data values from analysis results)

**Entities Panel**
- No-entities empty state: "Run analysis to extract entities"

**Toast messages**
- "Analysis complete"
- "Download started"

## What Was NOT Localized (per spec)

- `document.originalName` — file name (user data)
- `document.extractedText` — document content (AI result)
- `document.analysis.summary` — AI-generated summary
- `risk.title`, `risk.description`, `risk.clause` — AI analysis content
- `entity.value` — AI-extracted entity value
- `entity.type` — used only as icon selector, displayed via `titlecase`
- `document.language` value — data value from document metadata
- `document.fileType` value — data value used for display
