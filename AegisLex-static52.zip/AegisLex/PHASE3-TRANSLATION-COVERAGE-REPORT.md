# AegisLex — Phase 3: Translation Coverage Report

## Coverage Statistics

| Metric | Count |
|---|---|
| Total `lang.t()` calls in dashboard HTML | 29 |
| Total `lang.t()` calls in dashboard TS | 13 |
| Total new translation keys added (EN + AR) | 38 |
| Total keys in LanguageService after Phase 3 | 45 dashboard keys (Phase 3 adds 38 to existing 7) |
| Hardcoded UI strings eliminated | 42 |
| Hardcoded strings intentionally kept (mock data) | ~8 (activity time strings, data labels) |

## Coverage by Section

| Dashboard Section | EN/AR Covered | Notes |
|---|---|---|
| Header greeting | ✓ | 3 time-of-day variants |
| Header subtitle | ✓ | |
| Header buttons | ✓ | Ask Saul, Upload Document |
| Skeleton loading states | n/a | No text — skeleton is purely visual |
| Stat card labels (6) | ✓ | All 6 cards |
| Stat card change values | kept as-is | "+12%", "+3" etc. are data, not UI labels |
| Saul card | ✓ | Description, CTA, 4 chips, ARIA |
| Recent Cases card header | ✓ | Title, subtitle, "View all" |
| Recent Cases empty state | ✓ | Text + link |
| Case status badges | ✓ | 5 statuses via getStatusLabel() |
| Case date display | ✓ | Today/Yesterday/Xd ago + locale-aware format |
| Case title/number/client | kept as-is | User data — not translatable |
| Cases by Status chart | ✓ | Title, SVG aria-label, "Total" center |
| Cases by Status legend | kept as-is | Labels come from mock-data.ts (data layer) |
| Cases by Type chart | ✓ | Title |
| Cases by Type bar labels | kept as-is | Labels come from mock-data.ts (data layer) |
| Quick Upload | ✓ | Title, subtitle, CTA, hint |
| Activity Feed header | ✓ | Title, "Live" badge |
| Activity item text | kept as-is | Mock data content |
| Activity item time | kept as-is | Mock data strings |

## Remaining Hardcoded Strings (Intentional)

These strings were audited and deliberately excluded per spec rule "DO NOT TRANSLATE: Mock data, Database values":

1. `casesByStatus` labels: 'Active', 'Pending', 'Review', 'Closed' — originate from `mock-data.ts`
2. `casesByType` labels: 'Contract', 'Litigation', 'Compliance', 'Advisory' — originate from `mock-data.ts`
3. `mockActivity[].text` — AI result text, case names, document names
4. `mockActivity[].time` — "2 minutes ago", "1 hour ago" etc. (mock data display)
5. `statCards[5].change` — "2 due today" (mock metric data, not UI chrome)
6. `case_.status` raw value passed to `getStatusBadge()` for CSS class — display label handled separately via `getStatusLabel()`
