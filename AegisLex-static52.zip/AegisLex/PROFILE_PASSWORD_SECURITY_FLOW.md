# Profile Password Security Flow

Status: **Frontend complete. Backend integration commented-out, inactive.**
Scope: `src/app/features/profile/profile.component.ts` / `.html` / `.scss`

## 1. Overview

The Password & Security section of Profile lets a user change their password.
The flow is designed so the frontend never has to trust an unverified Current
Password, while still giving immediate, secure-feeling feedback.

Three fields are involved:
- **Current Password**
- **New Password**
- **Confirm New Password**

## 2. Current Password validation (no more "abc" = green)

Previously, Current Password used only `Validators.required`, so a 3-character
value like `"abc"` was already "valid" and rendered the green success state.

This is fixed by reusing the exact same `passwordValidator` from
`shared/auth-components/auth-validators.ts` (the single source of truth also
used by Register/Reset Password) on the `currentPassword` control:

```ts
currentPassword: ['', [Validators.required, passwordValidator]],
```

Current Password now stays **neutral or invalid** until it satisfies the same
format rules as a real password (8–64 chars, upper, lower, number, special
character). This is "format-valid", **not** "correct" — the frontend has no
way to know the real password, only the backend can confirm that.

## 3. Password gate (lock/unlock)

On load, **New Password** and **Confirm Password** start **disabled** via
Angular's reactive-forms `.disable()` (not just a CSS overlay — they are
genuinely non-interactive and excluded from `passwordForm` validity until
enabled).

A subscription on `currentPassword.valueChanges` recomputes a single signal,
`currentPasswordUnlocked`:

- **Locked** (`currentPasswordUnlocked() === false`): New/Confirm Password are
  `disabled`, show reduced opacity, a "not-allowed" cursor, `pointer-events:
  none`, a lock icon, and a hint: *"Enter your current password first"*.
- **Unlocked**: as soon as Current Password becomes format-valid, New/Confirm
  Password are `.enable()`d and rendered exactly like Register (see §4).

If Current Password is edited back to an invalid format after being unlocked,
the fields lock again automatically and their values are cleared.

`changePassword()` also has an explicit guard: because Angular excludes
disabled controls from `FormGroup.invalid`, the submit handler checks
`newPasswordFieldsLocked` first so a submission can never sneak through while
New/Confirm Password are disabled and empty.

## 4. Register parity

Once unlocked, New Password and Confirm Password reuse, unmodified:
- `passwordValidator` (regex rules)
- `passwordMatchValidator` (group-level match rule)
- `calcPasswordStrength` (strength meter)
- `<app-password-strength>` and `<app-password-requirements>` components
- Identical error message strings, icons, and show/hide toggle behavior

No second implementation was created.

## 5. Submit flow (current, mock-backed)

`changePassword()`:
1. Blocks submit if fields are still locked.
2. Blocks submit on standard form invalidity / password mismatch.
3. Simulates a successful backend call via `setTimeout` (existing mock
   behavior, unchanged): shows a success toast, collapses the section, and
   resets the form (which re-locks New/Confirm Password).

## 6. Future backend integration (commented out, inactive)

A fully-formed, commented call to a not-yet-existing
`this.authService.changePassword(...)` is included directly above the mock
`setTimeout` block in `changePassword()`. It documents the exact request/
response contract:

```
POST /profile/change-password
Request:  { currentPassword, newPassword }
Success:  { success: true }
Failure:  { success: false, message: "Current password is incorrect" }
```

This code is **inactive** — comments only. No API calls are made. No mocks
were removed.

## 7. Relock flow (on simulated backend-invalid response)

`handleIncorrectCurrentPasswordError()` implements §8/§9 of the spec, and is
wired into the (currently commented-out) backend failure branch:

1. Sets a `{ incorrect: true }` error on `currentPassword`, which renders
   "Current password is incorrect." beneath the field.
2. Clears New Password and Confirm Password values.
3. Re-locks New/Confirm Password (disables them, restores locked styling).
4. Leaves Current Password's value in place so the user can correct it.

## 8. Password safety

If Current Password is ever reported incorrect by the backend, no password
change is applied, no partial update occurs, and the old password remains
active — the relock flow above guarantees New/Confirm Password cannot be
submitted again until Current Password is corrected and re-validated.

## 9. Files modified

- `src/app/features/profile/profile.component.ts`
- `src/app/features/profile/profile.component.html`
- `src/app/features/profile/profile.component.scss`

No changes were made to: auth flow, routing, state management, mock data/
services, guards, layouts, or animations. `auth-validators.ts` (the shared
regex/validator source of truth) was read but **not modified** — its existing
exports were reused as-is.
