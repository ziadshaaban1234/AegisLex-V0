# AegisLex — Phase 4: Risk Assessment

## Overall Risk Level: LOW

All changes are either additive (new translation keys) or substitutive (string literals
→ lang.t() calls). No business logic, data flow, routing, state, or SCSS was modified.

## Change Risk Matrix

| Change | Risk | Rationale |
|---|---|---|
| 142 new TRANSLATION keys | None | Additive — existing keys untouched |
| `inject(LanguageService)` | None | Used across all other components already |
| `lang.t()` replacing string literals | Minimal | Falls back to key string if missing |
| Options arrays → `computed()` signals | Minimal | Same reactivity pattern as statCards in dashboard |
| `getStatusConfig/getPriorityConfig` labels via `lang.t()` | Minimal | Color/bg values unchanged; only label string changes |
| Toast calls using `lang.t()` | None | Same ToastService API, string values change only |
| `formatDate` locale switch | Minimal | `toLocaleDateString` is fully supported; graceful fallback |
| `panels` computed in contract-viewer | None | Same signal/computed pattern |
| `fieldError` returning `lang.t()` | None | Only called on touched/dirty invalid controls |
| `tabs` computed in case-detail | None | Only label string changes; `id` values unchanged (routing logic) |
| All SCSS files | None | **Zero SCSS changes — byte-identical to input** |
| Routing | None | No routes, guards, or resolvers touched |
| State (NgRx) | None | No store actions, reducers, selectors modified |
| Services | None | MockService, ToastService, DashboardService — all untouched |
| Mock mode / Demo mode | None | No mock data or mock adapter changes |
| Grok / Gemini preparation | None | Not touched |
| Backend preparation | None | Not touched |

## Tab ID Safety Note

The `tabs` array in `case-detail.component.ts` uses `computed()` to make labels reactive,
but the `.id` field values ('overview', 'documents', 'analysis', 'timeline', 'graph') are
TypeScript `as ActiveTab` literals — they are never passed to `lang.t()` and cannot change.
The `activeTab` signal compares against these literal IDs only. No routing or state logic is
affected by the label strings.

## Rollback Plan

Three groups of files to revert:
1. `language.service.ts` — remove Phase 4 keys (clearly marked `// ── PHASE 4:`)
2. Six `.component.ts` files — remove LanguageService injection + lang.t() calls
3. Six `.component.html` files — revert lang.t() bindings to English string literals
4. No SCSS rollback needed — none was modified
