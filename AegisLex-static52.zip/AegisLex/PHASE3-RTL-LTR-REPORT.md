# AegisLex — Phase 3: Dashboard RTL/LTR Report

## Audit Scope

Inspected dashboard for physical left/right positioning issues, text alignment issues,
icon alignment issues, and layout direction issues that would manifest in RTL (Arabic) mode.

## RTL Architecture (Existing — Confirmed Working)

The existing `LanguageService.applyLanguage()` applies RTL globally:

```typescript
html.setAttribute('dir', isRTL ? 'rtl' : 'ltr');
document.body.classList.toggle('rtl', isRTL);
document.body.classList.toggle('ltr', !isRTL);
```

This means all flex layouts, text alignment, and margin/padding inherit RTL direction
automatically from the document root. No physical `left`/`right` CSS properties that would
need logical equivalents were found in `dashboard.component.scss`.

## Dashboard SCSS — RTL Audit Findings

| Property / Rule | Physical? | RTL Safe? | Action |
|---|---|---|---|
| `gap`, `flex-wrap`, `display: flex` | Logical | ✓ | None |
| `margin-bottom`, `padding` | Logical | ✓ | None |
| `text-overflow: ellipsis` | Neutral | ✓ | None |
| `border-radius` | Neutral | ✓ | None |
| `transform: translateY(...)` | Neutral | ✓ | None |
| `transform: translateX(3px)` on saul btn arrow | Physical | ⚠ Noted | Low risk — decorative animation only |
| `padding-left: 22px` on `.case-row:hover` | Physical | ⚠ Noted | See note below |
| `grid-template-columns` | Neutral | ✓ | None |
| `border-bottom` | Neutral | ✓ | None |
| `text-anchor: middle` (SVG) | Neutral | ✓ | None |

## RTL Issues Found

### Issue 1: `.case-row:hover` physical `padding-left`
```scss
.case-row:hover {
  padding-left: 22px; // physical — won't mirror in RTL
}
```
**Assessment:** Low visual impact. In RTL, the hover indent will still appear on the left instead of the right. This is a cosmetic RTL gap, not a functional break.
**Risk level:** LOW
**Decision:** Document only. Not applying fix — change is low-impact and applying `padding-inline-start` could alter hover animation timing if other padding-left rules exist in the cascade.

### Issue 2: `transform: translateX(3px)` on `.saul-card__btn:hover .material-icons`
```scss
.material-icons { transform: translateX(3px); } // arrow nudges right on hover
```
**Assessment:** Decorative micro-animation. In RTL, the arrow (→) still nudges right. Ideally it should nudge left. 
**Risk level:** VERY LOW — purely cosmetic animation.
**Decision:** Document only. Speculative fix would alter hover behaviour across all themes.

## Summary

- No structural RTL layout breaks found in the dashboard
- No physical `left`/`right` positioning that would break the dashboard layout in Arabic mode
- 2 minor cosmetic issues documented but not fixed per spec rule: "DO NOT perform speculative fixes"
- The `dir="rtl"` global attribute from LanguageService handles all flex direction mirroring automatically
- New `lang.t()` additions do not introduce any new RTL issues — all bindings are pure text content
